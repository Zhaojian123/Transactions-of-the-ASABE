
# coding: utf-8

# In[1]:

get_ipython().magic('matplotlib inline')
import h5py
import pickle as pkl
import time
from distutils.version import LooseVersion
import warnings
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat
from scipy.io import savemat
import tensorflow as tf
import cv2
extra_class = 0
e=1.5
class_num=12
class_expand=int(np.round(e*class_num))


# Check TensorFlow Version
assert LooseVersion(tf.__version__) >= LooseVersion('1.0'), 'Please use TensorFlow version 1.0 or newer.  You are using {}'.format(tf.__version__)
print('TensorFlow Version: {}'.format(tf.__version__))

# Check for a GPU
if not tf.test.gpu_device_name():
    warnings.warn('No GPU found. Please use a GPU to train your neural network.')
else:
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))


# In[ ]:

data_dir = '/home/amax/Downloads/croatianFishDataset/t10/'
trainset = loadmat(data_dir + 'trainset.mat')
testset = loadmat(data_dir + 'testset.mat')
#change the path and the file name for test and practical use


# In[ ]:

def scale(x, feature_range=(-1, 1)):
    # scale to (0, 1)
    x = ((x - x.min())/(x.max() - x.min()))
    min, max = feature_range
    
    x = x * (max - min) + min
    return x


# In[ ]:

class Dataset:
    def __init__(self, train, test, shuffle=True, scale_func=None):
        
        self.test_x = (np.array(test['testdata']))
        self.test_y= (np.array(test['testlab']))
        #self.test_h = (np.array(test['testh']))
        #self.test_w = (np.array(test['testw']))
        
        self.train_x, self.train_y = np.array(train['traindata']), np.array(train['trainlab'])
        #self.train_h, self.train_w = np.array(train['trainh']), np.array(train['trainw'])

        self.label_mask = np.zeros_like(self.train_y)
        self.label_mask[0:155] = 1
        # label mask here is equal to the number of the labeled training data.
        
        self.train_x = np.rollaxis(self.train_x, 3)
        self.test_x = np.rollaxis(self.test_x, 3)
        
        if scale_func is None:
            self.scaler = scale
        else:
            self.scaler = scale_func
        self.shuffle = shuffle
        
    def batches(self, batch_size, which_set="train"):
        x_name = which_set + "_x"
        y_name = which_set + "_y"
       # h_name = which_set + "_h"
        #w_name = which_set + "_w"
        
        num_examples = len(getattr(dataset, y_name))
       # print (num_examples)
        if self.shuffle:
            idx = np.arange(num_examples)
            np.random.shuffle(idx)
            setattr(dataset, x_name, getattr(dataset, x_name)[idx])
            setattr(dataset, y_name, getattr(dataset, y_name)[idx])
            #setattr(dataset, h_name, getattr(dataset, h_name)[idx])
            #setattr(dataset, w_name, getattr(dataset, w_name)[idx])
            if which_set == "train":
                dataset.label_mask = dataset.label_mask[idx]
        
        dataset_x = getattr(dataset, x_name)
        dataset_y = getattr(dataset, y_name)
       # dataset_h = getattr(dataset, h_name)
        #dataset_w = getattr(dataset, w_name)
        
        for ii in range(0, num_examples, batch_size):
            x1 = dataset_x[ii:ii+batch_size]
            y = dataset_y[ii:ii+batch_size]
            #y.dtype='int64'
            #h = dataset_h[ii:ii+batch_size]
            #w = dataset_w[ii:ii+batch_size]
            
            #hh=int(np.around(np.mean(h)))
            #ww=int(np.around(np.mean(w)))
            #hw=int(np.around(np.mean([hh,ww])))
            #x=np.random.normal(size=(y.size,hh,ww,3))
            #for jj in range(0,y.size):
               # s=x1[jj,0:(h[jj,0]),0:(w[jj,0]),:]
                #x[jj]=cv2.resize(s,(ww,hh),interpolation=cv2.INTER_AREA)
                #INTER_CUBIC INTER_AREA INTER_LINEAR INTER_NN
            x = self.scaler(x1)
           
            if which_set == "train":
                # As a semi-supervised learning model,when we use the data for training, we need to include
                # the label mask, so we can pretend we don't have access
                # to some of the labels.
                yield x, y, self.label_mask[ii:ii+batch_size]
            else:
                yield x, y


# In[ ]:

def max_pool_2d_nxn_regions(inputs, output_size: int, mode: str):
    """
    Performs a pooling operation that results in a fixed size:
    output_size x output_size.
    
    Used by spatial_pyramid_pool. Refer to appendix A in [1].
    
    Args:
        inputs: A 4D Tensor (B, H, W, C)
        output_size: The output size of the pooling operation.
        mode: The pooling mode {max, avg}
        
    Returns:
        A list of tensors, for each output bin.
        The list contains output_size * output_size elements, where
        each elment is a Tensor (N, C).
        
    References:
        [1] He, Kaiming et al (2015):
            Spatial Pyramid Pooling in Deep Convolutional Networks
            for Visual Recognition.
            https://arxiv.org/pdf/1406.4729.pdf.
            
    Ported from: https://github.com/luizgh/Lasagne/commit/c01e3d922a5712ca4c54617a15a794c23746ac8c
    """
    inputs_shape = tf.shape(inputs)
    h = tf.cast(tf.gather(inputs_shape, 1), tf.int32)
    w = tf.cast(tf.gather(inputs_shape, 2), tf.int32)
    
    if mode == 'max':
        pooling_op = tf.reduce_max
    elif mode == 'avg':
        pooling_op = tf.reduce_mean
    else:
        msg = "Mode must be either 'max' or 'avg'. Got '{0}'"
        raise ValueError(msg.format(mode))
        
    result = []
    n = output_size
    for row in range(output_size):
        for col in range(output_size):
            # start_h = floor(row / n * h)
            start_h = tf.cast(tf.floor(tf.multiply(tf.divide(row, n), tf.cast(h, tf.float32))), tf.int32)
            # end_h = ceil((row + 1) / n * h)
            end_h = tf.cast(tf.ceil(tf.multiply(tf.divide((row + 1), n), tf.cast(h, tf.float32))), tf.int32)
            # start_w = floor(col / n * w)
            start_w = tf.cast(tf.floor(tf.multiply(tf.divide(col, n), tf.cast(w, tf.float32))), tf.int32)
            # end_w = ceil((col + 1) / n * w)
            end_w = tf.cast(tf.ceil(tf.multiply(tf.divide((col + 1), n), tf.cast(w, tf.float32))), tf.int32)
            pooling_region = inputs[:, start_h:end_h, start_w:end_w, :]
            pool_result = pooling_op(pooling_region, axis=(1, 2))
            #pool_result =tf.to_int32( pool_result )
            #result.append(tf.reshape(pool_result,[inputs_shape[0],-1]))
            result.append(pool_result)
    return result

def spatial_pyramid_pool(inputs, dimensions=[2,1], mode='max', implementation='kaiming'):
    """
    Performs spatial pyramid pooling (SPP) over the input.
    It will turn a 2D input of arbitrary size into an output of fixed
    dimenson.
    Hence, the convlutional part of a DNN can be connected to a dense part
    with a fixed number of nodes even if the dimensions of the input
    image are unknown.
    
    The pooling is performed over :math:`l` pooling levels.
    Each pooling level :math:`i` will create :math:`M_i` output features.
    :math:`M_i` is given by :math:`n_i * n_i`, with :math:`n_i` as the number
    of pooling operations per dimension level :math:`i`.
    
    The length of the parameter dimensions is the level of the spatial pyramid.
    
    Args:
        inputs: A 4D Tensor (B, H, W, C).
        dimensions: The list of :math:`n_i`'s that define the output dimension
        of each pooling level :math:`i`. The length of dimensions is the level of
        the spatial pyramid.
        mode: Pooling mode 'max' or 'avg'.
        implementation: The implementation to use, either 'kaiming' or 'fast'.
        kamming is the original implementation from the paper, and supports variable
        sizes of input vectors, which fast does not support.
    
    Returns:
        A fixed length vector representing the inputs.
    
    Notes:
        SPP should be inserted between the convolutional part of a DNN and it's
        dense part. Convolutions can be used for arbitrary input dimensions, but
        the size of their output will depend on their input dimensions.
        Connecting the output of the convolutional to the dense part then
        usually demands us to fix the dimensons of the network's input.
        The spatial pyramid pooling layer, however, allows us to leave 
        the network input dimensions arbitrary. 
        The advantage over a global pooling layer is the added robustness 
        against object deformations due to the pooling on different scales.
        
    References:
        [1] He, Kaiming et al (2015):
            Spatial Pyramid Pooling in Deep Convolutional Networks
            for Visual Recognition.
            https://arxiv.org/pdf/1406.4729.pdf.
            
    Ported from: https://github.com/luizgh/Lasagne/commit/c01e3d922a5712ca4c54617a15a794c23746ac8c
    """
    pool_list = []
    if implementation == 'kaiming':
        for pool_dim in dimensions:
            pool_list += max_pool_2d_nxn_regions(inputs, pool_dim, mode)
    else:
        shape = inputs.get_shape().as_list()
        for d in dimensions:
            h = shape[1]
            w = shape[2]
            ph = np.ceil(h * 1.0 / d).astype(np.int32)
            pw = np.ceil(w * 1.0 / d).astype(np.int32)
            sh = np.floor(h * 1.0 / d + 1).astype(np.int32)
            sw = np.floor(w * 1.0 / d + 1).astype(np.int32)
            pool_result = tf.nn.max_pool(inputs,
                                         ksize=[1, ph, pw, 1], 
                                         strides=[1, sh, sw, 1],
                                         padding='SAME')
            pool_list.append(tf.reshape(pool_result, [tf.shape(inputs)[0], -1]))
    return tf.concat(pool_list,1)


# In[ ]:

def model_inputs(real_dim, z_dim):
    inputs_real = tf.placeholder(tf.float32, (None,None,None,3), name='input_real')
    #you can change 3 to 1 when the input images are grayscale
    inputs_z = tf.placeholder(tf.float32, (None, z_dim), name='input_z')
    y = tf.placeholder(tf.int32, (None), name='y')
    label_mask = tf.placeholder(tf.int32, (None), name='label_mask')
    
    return inputs_real, inputs_z, y, label_mask


# In[ ]:

def generator(z, output_dim, reuse=False, alpha=0.2, training=True, size_mult=128):
    keep_prob=0.8
    with tf.variable_scope('generator', reuse=reuse):
  
        x1 = tf.layers.dense(z, 4 * 4* size_mult * 8,kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
  
        x1 = tf.reshape(x1, (-1, 4, 4, size_mult * 8))
        x1 = tf.layers.batch_normalization(x1, training=training)
        x1 = tf.maximum(alpha * x1, x1)

        x2 = tf.layers.conv2d_transpose(x1, size_mult * 4, 5, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        x2 = tf.layers.batch_normalization(x2, training=training)
        x2 = tf.maximum(alpha * x2, x2)
        
        x3 = tf.layers.conv2d_transpose(x2, size_mult * 2, 5, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        x3 = tf.layers.batch_normalization(x3, training=training)
        x3 = tf.maximum(alpha * x3, x3)
               
        x4 = tf.layers.conv2d_transpose(x3, size_mult*1, 5, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        x4 = tf.layers.batch_normalization(x4, training=training)
        x4 = tf.maximum(alpha * x4, x4)

        x5= tf.layers.conv2d_transpose(x4, size_mult*1, 5, strides=1, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        x5 = tf.layers.batch_normalization(x5, training=training)
        x5 = tf.maximum(alpha * x5, x5)
 
        logits = tf.layers.conv2d_transpose(x5, output_dim, 5, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        
        out = tf.tanh(logits)
        print (out.shape)
        
        return out


# In[ ]:

def discriminator(x, reuse=False, alpha=0.2, drop_rate=0.2, num_classes=class_expand, size_mult=128):
    with tf.variable_scope('discriminator', reuse=reuse):

        x = tf.layers.dropout(x, rate=drop_rate/2.5)           
        
        x1 = tf.layers.conv2d(x, size_mult*1, 3, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        relu1 = tf.maximum(alpha * x1, x1)
        relu1 = tf.layers.dropout(relu1, rate=drop_rate)
                
        x2 = tf.layers.conv2d(relu1, 2*size_mult, 3, strides=2, kernel_initializer= tf.truncated_normal_initializer(stddev=0.01),padding='same')
        bn2 = tf.layers.batch_normalization(x2, training=True)
        relu2 = tf.maximum(alpha * x2, x2)
        relu2 = tf.layers.dropout(relu2, rate=drop_rate)
              
        x3 = tf.layers.conv2d(relu2, 4*size_mult, 3, strides=2, kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),padding='same')
        bn3 = tf.layers.batch_normalization(x3, training=True)
        relu3 = tf.maximum(alpha * bn3, bn3)
        relu3 = tf.layers.dropout(relu3, rate=drop_rate)
                                          
        x4 = tf.layers.conv2d(relu3, 8 * size_mult, 3, strides=2, kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),padding='same')
        bn4 = tf.layers.batch_normalization(x4, training=True)
        relu4 = tf.maximum(alpha * bn4, bn4)
        relu4 = tf.layers.dropout(relu4, rate=drop_rate)
        
        x5 = tf.layers.conv2d(relu4, 8 * size_mult, 3, strides=1, kernel_initializer=tf.truncated_normal_initializer(stddev=0.01),padding='same')
        relu5 = tf.maximum(alpha * x5, x5)
        relu5 = tf.layers.dropout(relu5, rate=drop_rate)
       
        features = spatial_pyramid_pool(relu5, dimensions=[2,1], mode='max', implementation='kaiming')
        class_logits = tf.layers.dense(features, num_classes + extra_class,kernel_initializer=tf.truncated_normal_initializer(stddev=0.01))
       
        if extra_class:
            real_class_logits, fake_class_logits = tf.split(class_logits, [num_classes, 1], 1)
            assert fake_class_logits.get_shape()[1] == 1, fake_class_logits.get_shape()
            fake_class_logits = tf.squeeze(fake_class_logits)
        else:
            real_class_logits = class_logits
            fake_class_logits = 0.
        
        mx = tf.reduce_max(real_class_logits, 1, keep_dims=True)
        stable_real_class_logits = real_class_logits - mx

        gan_logits = tf.log(tf.reduce_sum(tf.exp(stable_real_class_logits), 1)) + tf.squeeze(mx) - fake_class_logits
        
        out = tf.nn.softmax(class_logits)
        
        return out, class_logits, gan_logits, features


# In[ ]:

def model_loss(input_real, input_z, output_dim, y, num_classes, label_mask, alpha=0.2, drop_rate=0.2):
    
    #  g_size_mult and d_size_mult determine the size of each layer in generator and discriminator,
    # respectively. You can adjust them to run your code faster.
    g_size_mult =128
    d_size_mult =128
    smooth=0.1

    g_model = generator(input_z, output_dim, alpha=alpha, size_mult=g_size_mult)
    d_on_data = discriminator(input_real, alpha=alpha, drop_rate=drop_rate, size_mult=d_size_mult)
    d_model_real, class_logits_on_data, gan_logits_on_data, data_features,data_features1 = d_on_data
    d_on_samples = discriminator(g_model, reuse=True, alpha=alpha, drop_rate=drop_rate, size_mult=d_size_mult)
    d_model_fake, class_logits_on_samples, gan_logits_on_samples, sample_features,sample_features1 = d_on_samples
    

    d_loss_real = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=gan_logits_on_data,
                                                labels=tf.ones_like(gan_logits_on_data)*(1-smooth)))
    d_loss_fake = tf.reduce_mean(
        tf.nn.sigmoid_cross_entropy_with_logits(logits=gan_logits_on_samples,
                                                labels=tf.zeros_like(gan_logits_on_samples)))
    y = tf.squeeze(y)
    class_cross_entropy = tf.nn.softmax_cross_entropy_with_logits(logits=class_logits_on_data,
                                                                  labels=tf.one_hot(y, num_classes + extra_class,
                                                                                    dtype=tf.float32))
    class_cross_entropy = tf.squeeze(class_cross_entropy)
    label_mask = tf.squeeze(tf.to_float(label_mask))
    d_loss_class = tf.reduce_sum(label_mask * class_cross_entropy) / tf.maximum(1., tf.reduce_sum(label_mask))
    d_loss = d_loss_class + d_loss_real + d_loss_fake


    data_moments = tf.reduce_mean(data_features, axis=0)
    sample_moments = tf.reduce_mean(sample_features, axis=0)
    g_loss = tf.reduce_mean(tf.abs(data_moments - sample_moments))
    pred_class = tf.cast(tf.argmax(class_logits_on_data, 1), tf.int32)
    eq = tf.equal(tf.squeeze(y), pred_class)
    correct = tf.reduce_sum(tf.to_float(eq))
    masked_correct = tf.reduce_sum(label_mask * tf.to_float(eq))
  
    return d_loss, g_loss, correct, masked_correct, g_model,tf.squeeze(y),pred_class


# In[ ]:

def model_opt(d_loss, g_loss, learning_rate, beta1):

    t_vars = tf.trainable_variables()
    d_vars = [var for var in t_vars if var.name.startswith('discriminator')]
    g_vars = [var for var in t_vars if var.name.startswith('generator')]
    for t in t_vars:
        assert t in d_vars or t in g_vars
    
    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
        
        d_train_opt = tf.train.AdamOptimizer(learning_rate, beta1=beta1).minimize(d_loss, var_list=d_vars)
        g_train_opt = tf.train.AdamOptimizer(learning_rate, beta1=beta1).minimize(g_loss, var_list=g_vars)
        
    shrink_lr = tf.assign(learning_rate, learning_rate * 0.9)

    return d_train_opt, g_train_opt, shrink_lr


# In[ ]:

class GAN:

    def __init__(self, real_size, z_size, learning_rate, num_classes=class_expand, alpha=0.2, beta1=0.5):
        tf.reset_default_graph()
        
        self.learning_rate = tf.Variable(learning_rate, trainable=False)
        self.input_real, self.input_z, self.y, self.label_mask = model_inputs(real_size, z_size)
        self.drop_rate = tf.placeholder_with_default(.25, (), "drop_rate")
        
        loss_results = model_loss(self.input_real, self.input_z,
                                              real_size[2], self.y, num_classes, label_mask=self.label_mask,
                                                                          alpha=0.2,
                                                           drop_rate=self.drop_rate)
        self.d_loss, self.g_loss, self.correct, self.masked_correct, self.samples,self.y1, self.pred_class = loss_results
        
        self.d_opt, self.g_opt, self.shrink_lr = model_opt(self.d_loss, self.g_loss, self.learning_rate, beta1)


# In[ ]:

def view_samples(epoch, samples, nrows, ncols, figsize=(5,5)):
    fig, axes = plt.subplots(figsize=figsize, nrows=nrows, ncols=ncols, 
                             sharey=True, sharex=True)
    for ax, img in zip(axes.flatten(), samples[epoch]):
        ax.axis('off')
        img = ((img - img.min())*255 / (img.max() - img.min())).astype(np.uint8)
        ax.set_adjustable('box-forced')
        im = ax.imshow(img)
   
    plt.subplots_adjust(wspace=0, hspace=0)
    return fig, axes


# In[ ]:

def train(net, dataset, epochs, batch_size, figsize=(5,5)):
    
    saver = tf.train.Saver()

    samples, train_accuracies, test_accuracies, test_accuracies2, test_accuracies1 = [], [], [],[],[]
    steps = 0
    num_classes1=12 
    #the actual number of fish species, which was used to calculated the average identification accuracy

    with tf.Session() as sess:
        
        sess.run(tf.global_variables_initializer())
        for e in range(epochs):
            print("Epoch",e)
            
            t1e = time.time()
            num_examples = 0
            num_correct = 0
            #training
            for x, y, label_mask in dataset.batches(batch_size):
                assert 'int' in str(y.dtype)
                steps += 1
                num_examples += label_mask.sum()

                # Random noise vector z for generator
                #batch_z = np.random.normal(0, 1, size=(batch_size, z_size))
                batch_z = np.random.uniform(-1, 1, size=(batch_size, z_size))
 
                t1 = time.time()
                _, _, correct = sess.run([net.d_opt, net.g_opt, net.masked_correct],
                                         feed_dict={net.input_real: x, net.input_z: batch_z,
                                                    net.y : y, net.label_mask : label_mask})
                t2 = time.time()
                num_correct += correct

            sess.run([net.shrink_lr])
            train_accuracy = num_correct / float(num_examples)
            print("\t comprehensive train accuracy: ", train_accuracy)
            t2e = time.time()
                  
            num_examples = 0
            num_correct = 0
            num_correct1=np.zeros((num_classes1,1))
            num_correct2=np.zeros((num_classes1,1))
            num_correct3=np.zeros((num_classes1,num_classes1))
            
            #test
            for x, y in dataset.batches(batch_size, which_set="test"):
                assert 'int' in str(y.dtype)
                num_examples += x.shape[0]

                correct, y1, pred_class, = sess.run([net.correct, net.y1, net.pred_class], feed_dict={net.input_real: x,
                                                                                           net.y : y,
                                                                                           net.drop_rate: 0.})
                num_correct += correct
                
                correct1=np.zeros((num_classes1,1))
                correct2=np.zeros((num_classes1,1))
                correct3=np.zeros((num_classes1,num_classes1))
                for j in range(1,num_classes1+1): 
                    
                    cy= [i1 for i1,v1 in enumerate(np.array(y1)) if v1==j]
                    cp1= (np.array(pred_class))[cy]
                    cy1= (np.array(y1))[cy]
                    eq1 = np.equal(cy1, cp1)
                    #print (eq1.eval())
                    correct1[j-1,0] = (np.sum((eq1)))
                    correct2[j-1,0]=len(cy)
                    for jj in range (1,num_classes1+1):
                        cy2= [i2 for i2,v2 in enumerate(cp1) if v2==jj]
                        correct3[j-1,jj-1]=len(cy2)
                num_correct1=np.add(num_correct1, correct1)  
                num_correct2=np.add(num_correct2, correct2) 
                num_correct3=(np.add(num_correct3, correct3)).astype(np.int64)
                
            test_accuracy1=(np.divide(num_correct1,num_correct2))
            test_accuracy2=(np.mean(np.divide(num_correct1,num_correct2)))  
            test_accuracy = num_correct / float(num_examples)
            print("\t comprehensive test accuracy", test_accuracy)
            print("\t average test accuracy",test_accuracy2)
            print("\t accuracy for each species",test_accuracy1)
            print("\t Step time in training: ", t2 - t1)
            print("\t Epoch time in training: ", t2e - t1e)
            print("\t Confusion matrix: ", num_correct3)
                       
            gen_samples = sess.run(
                                   net.samples,
                                   feed_dict={net.input_z: sample_z})
            samples.append(gen_samples)
            _ = view_samples(-1, samples, 5, 10, figsize=figsize)
            plt.show()
            
            # Save history of accuracies
            train_accuracies.append(train_accuracy)
            test_accuracies.append(test_accuracy)
            test_accuracies2.append(test_accuracy2)
            test_accuracies1.append(test_accuracy1)
    
    return train_accuracies, test_accuracies, test_accuracies2, test_accuracies1,samples


# In[ ]:

z_size = 100 # length of noise vector z
learning_rate = 0.0002 #we suggest setting it between 0.0001-0.0003
batch_size = 32 
#To the datasets in our study, we suggest 32, normally it shoudl be set to 32 64,128, 256. 
#However, in practical use, 256 would be counterproductive. 
epochs = 300 
net = GAN(real_size, z_size, learning_rate)
dataset = Dataset(trainset, testset)
train_accuracies, test_accuracies, test_accuracies2, test_accuracies1, samples = train(net, dataset, epochs, batch_size, figsize=(10,5))


# In[ ]:

#save the data what you want
savemat('/home/amax/Downloads/croatianFishDataset/07512.mat',{'accuracy':test_accuracies1})
savemat('/home/amax/Downloads/fishRecognition_GT/151011.mat',{'accuracy':test_accuracies2})
#display
fig, ax = plt.subplots()
plt.plot(train_accuracies, label='comprehensive train accuracy', alpha=0.5)
plt.plot(test_accuracies, label='comprehensive test accuracy', alpha=0.5)
plt.plot(test_accuracies2, label='average test accuracy', alpha=0.5)
plt.title("Accuracy")
plt.legend()

